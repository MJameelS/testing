from django.shortcuts import render, redirect
from .models import *
from .form import *

# Create your views here.

def landing(request):
    # dictionary for initial data with 
    # field names as keys
    if request.method == 'POST':
        form = TamuForm(request.POST)
        print(form)
        if form.is_valid():
            form.save()
            print('MASUK VALID')
            return redirect('home')
    context ={}
 
    # add the dictionary during initialization
    context["dataset"] = Tabel.objects.all()
    context["Tamu"] = Tamu.objects.all()
    return render(request, "index.html", context)

# def tamu(request):
#     # dictionary for initial data with 
#     # field names as keys
#     context ={}
 
#     # add the dictionary during initialization
#     context["Tamu"] = Tamu.objects.all()
#     return render(request, "daftar.html", context)

